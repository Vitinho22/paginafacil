"use client";

import { useEffect, useRef } from "react";
import { renderBannerToCanvas } from "./BannerEditor";
import { BannerState } from "./BannerEditor";

interface CanvasProps {
  banner: BannerState;
  canvasRef: React.RefObject<HTMLCanvasElement> | null;
}

export default function Canvas({ banner, canvasRef }: CanvasProps) {
  const internalCanvasRef = useRef<HTMLCanvasElement>(null);
  const canvasToUse = canvasRef || internalCanvasRef;

  useEffect(() => {
    if (canvasToUse.current && banner.image) {
      renderBannerToCanvas(canvasToUse.current, banner);
    }
  }, [banner, canvasToUse]);

  return (
    <div className="canvas-wrapper">
      <div className="canvas-info">
        <span>1080 x 1080px • Instagram</span>
      </div>
      <canvas
        ref={canvasToUse}
        width={1080}
        height={1080}
        className="banner-canvas"
      />
    </div>
  );
}
