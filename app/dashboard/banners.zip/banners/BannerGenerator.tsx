"use client";

import { BannerState } from "./BannerEditor";

interface BannerGeneratorProps {
  banner: BannerState;
  onVariantSelect: (variant: BannerState) => void;
}

export default function BannerGenerator({
  banner,
  onVariantSelect,
}: BannerGeneratorProps) {
  const generateVariant = () => {
    // Esta função é chamada pelo BannerEditor
    console.log("Gerando variações...");
  };

  return (
    <div className="banner-generator">
      <button onClick={generateVariant} className="generate-variations-btn">
        ⚡ Gerar Variações Automáticas
      </button>
    </div>
  );
}
