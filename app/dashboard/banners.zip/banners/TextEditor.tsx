"use client";

import { BannerState } from "./BannerEditor";

interface TextEditorProps {
  banner: BannerState;
  onTextChange: (field: string, value: string) => void;
}

export default function TextEditor({ banner, onTextChange }: TextEditorProps) {
  return (
    <div className="text-editor">
      <div className="text-field">
        <label>Título Principal</label>
        <input
          type="text"
          value={banner.title}
          onChange={(e) => onTextChange("title", e.target.value)}
          maxLength={50}
          placeholder="Digite seu título"
          className="text-input"
        />
        <small>{banner.title.length}/50</small>
      </div>

      <div className="text-field">
        <label>Subtítulo</label>
        <textarea
          value={banner.subtitle}
          onChange={(e) => onTextChange("subtitle", e.target.value)}
          maxLength={100}
          placeholder="Digite o subtítulo"
          className="text-input"
          rows={3}
        />
        <small>{banner.subtitle.length}/100</small>
      </div>

      <div className="text-field">
        <label>Chamada para Ação (CTA)</label>
        <input
          type="text"
          value={banner.cta}
          onChange={(e) => onTextChange("cta", e.target.value)}
          maxLength={30}
          placeholder="Ex: Saiba Mais"
          className="text-input"
        />
        <small>{banner.cta.length}/30</small>
      </div>
    </div>
  );
}
