"use client";

import React, { useState, useRef, useEffect } from "react";
import LayoutSelector from "./LayoutSelector";
import TextEditor from "./TextEditor";
import Canvas from "./Canvas";
import ExportPanel from "./ExportPanel";
import ImageUpload from "./ImageUpload";

export interface BannerState {
  image: string | null;
  title: string;
  subtitle: string;
  cta: string;
  layoutId: number;
  textColor: string;
  accentColor: string;
  variant: number;
}

export default function BannerEditor() {
  const [banner, setBanner] = useState<BannerState>({
    image: null,
    title: "Transforme Seu Negócio",
    subtitle: "Crie campanhas profissionais em segundos",
    cta: "Comece Agora",
    layoutId: 0,
    textColor: "#ffffff",
    accentColor: "#667eea",
    variant: 0,
  });

  const [generatingVariants, setGeneratingVariants] = useState(false);
  const [variants, setVariants] = useState<BannerState[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleImageUpload = (imageData: string) => {
    setBanner(prev => ({ ...prev, image: imageData }));
  };

  const handleLayoutChange = (layoutId: number) => {
    setBanner(prev => ({ ...prev, layoutId }));
  };

  const handleTextChange = (field: string, value: string) => {
    setBanner(prev => ({ ...prev, [field]: value }));
  };

  const handleColorChange = (field: string, color: string) => {
    setBanner(prev => ({ ...prev, [field]: color }));
  };

  const handleGenerateVariants = async () => {
    setGeneratingVariants(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newVariants = Array.from({ length: 5 }).map((_, i) => ({
      ...banner,
      variant: i,
      layoutId: i % 6,
      accentColor: [
        "#667eea",
        "#764ba2",
        "#f93b1d",
        "#00b8a9",
        "#fb5607",
      ][i],
    }));

    setVariants(newVariants);
    setGeneratingVariants(false);
  };

  const handleSelectVariant = (variant: BannerState) => {
    setBanner(variant);
    setVariants([]);
  };

  return (
    <div className="banner-editor-container">
      <header className="editor-header">
        <div className="header-content">
          <h1>🎨 Banner Studio Pro</h1>
          <p>Crie banners profissionais com IA em segundos</p>
        </div>
      </header>

      <div className="editor-main">
        {/* Painel Esquerdo - Controles */}
        <aside className="editor-sidebar">
          <div className="sidebar-section">
            <h2>📸 Sua Imagem</h2>
            <ImageUpload onImageUpload={handleImageUpload} />
          </div>

          <div className="sidebar-section">
            <h2>✏️ Conteúdo</h2>
            <TextEditor banner={banner} onTextChange={handleTextChange} />
          </div>

          <div className="sidebar-section">
            <h2>🎯 Layout</h2>
            <LayoutSelector 
              currentLayout={banner.layoutId} 
              onLayoutChange={handleLayoutChange}
            />
          </div>

          <div className="sidebar-section">
            <h2>🎨 Cores</h2>
            <div className="color-controls">
              <div className="color-group">
                <label>Texto</label>
                <input
                  type="color"
                  value={banner.textColor}
                  onChange={e => handleColorChange("textColor", e.target.value)}
                  className="color-input"
                />
              </div>
              <div className="color-group">
                <label>Destaque</label>
                <input
                  type="color"
                  value={banner.accentColor}
                  onChange={e => handleColorChange("accentColor", e.target.value)}
                  className="color-input"
                />
              </div>
            </div>
          </div>

          <button 
            className="generate-btn"
            onClick={handleGenerateVariants}
            disabled={!banner.image || generatingVariants}
          >
            {generatingVariants ? "⚡ Gerando..." : "⚡ Gerar Variações"}
          </button>
        </aside>

        {/* Painel Central - Canvas */}
        <section className="editor-canvas">
          <Canvas 
            banner={banner} 
            canvasRef={canvasRef as React.RefObject<HTMLCanvasElement>}
          />
          <ExportPanel canvasRef={canvasRef as React.RefObject<HTMLCanvasElement>} />
        </section>

        {/* Painel Direito - Variações */}
        {variants.length > 0 && (
          <aside className="editor-variants">
            <h2>✨ Variações Geradas</h2>
            <div className="variants-grid">
              {variants.map((variant, idx) => (
                <div 
                  key={idx}
                  className="variant-card"
                  onClick={() => handleSelectVariant(variant)}
                >
                  <div className="variant-preview">
                    <Canvas banner={variant} canvasRef={null} />
                  </div>
                  <p>Variação {idx + 1}</p>
                </div>
              ))}
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
