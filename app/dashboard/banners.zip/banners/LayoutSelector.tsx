"use client";

import { BannerState } from "./BannerEditor";

interface LayoutSelectorProps {
  currentLayout: number;
  onLayoutChange: (layoutId: number) => void;
}

const layouts = [
  {
    id: 0,
    name: "Imagem + Texto Centralizado",
    description: "Texto no centro sobre a imagem",
    icon: "📍",
  },
  {
    id: 1,
    name: "Texto em Cima",
    description: "Título no topo com fundo escuro",
    icon: "⬆️",
  },
  {
    id: 2,
    name: "Texto Embaixo",
    description: "CTA fixo na base",
    icon: "⬇️",
  },
  {
    id: 3,
    name: "Lado Esquerdo",
    description: "Texto à esquerda, imagem à direita",
    icon: "👈",
  },
  {
    id: 4,
    name: "Lado Direito",
    description: "Imagem à esquerda, texto à direita",
    icon: "👉",
  },
  {
    id: 5,
    name: "Overlay Gradient",
    description: "Gradiente colorido sobre imagem",
    icon: "🌈",
  },
];

export default function LayoutSelector({
  currentLayout,
  onLayoutChange,
}: LayoutSelectorProps) {
  return (
    <div className="layout-selector">
      <div className="layouts-grid">
        {layouts.map((layout) => (
          <button
            key={layout.id}
            className={`layout-card ${
              currentLayout === layout.id ? "active" : ""
            }`}
            onClick={() => onLayoutChange(layout.id)}
            title={layout.description}
          >
            <span className="layout-icon">{layout.icon}</span>
            <span className="layout-name">{layout.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
